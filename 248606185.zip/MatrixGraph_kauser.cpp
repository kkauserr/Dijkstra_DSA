/*
Author: Jameela Kauser
Date: 4/20/2024
Description: Adjancency Matrix Graph used as connection graph 
*/
#include "MatrixGraph_kauser.h"
#include "Queue_kauser.hpp"
#include <limits>
#include <queue>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <string>
#include <iostream>

MatrixGraph::MatrixGraph(int vert,bool isDirected)
{
    matrix.resize(vert);
    vertice=vert;
    directed=isDirected;
    for(int i=0; i<vert;++i)
    {
        matrix[i].resize(vertice, 0.0f);
    }
}
void MatrixGraph::addEdge(int from, int to, float weight)
{
    matrix[from][to]=weight;
}
void MatrixGraph::addEdge(int from, int to)
{
    matrix[from][to]=1.00;
}
void MatrixGraph::removeEdge(int from, int to)
{
    matrix[from][to]= 0.00;
    if(!directed)
    {
        matrix[to][from]=0.00;
    }
}
float MatrixGraph::getEdgeWeight(int from,int to)
{
    return matrix[from][to];
}
void MatrixGraph::setEdgeWeight(int from,int to, float weight)
{
    matrix[from][to]=weight;
    if(!directed)
    {
        matrix[to][from]=weight;
    }
}
bool MatrixGraph::adjacent(int from, int to)
{
    if (matrix[from][to]>0.00)
    {
       return true;
    }
    else
    return false;
}
std::string MatrixGraph::toString()
{
    std::stringstream graph;
    for(int i=0; i<vertice; i++)
    {
        graph<<"["<<std::setw(2)<<i+1<<"]:";
        for(int j=0; j<vertice;j++)
        {
            if(matrix[i][j]>0.00)
            {
                graph<<"-->"<<"["<<std::setw(2)<<i+1<<","<<std::setw(2)<<j+1<<"::"<<std::setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(matrix[i][j])<<"]";

            }
        }
        graph<<"\n";
    }
    return graph.str();
}
void MatrixGraph::printRaw()
{
    for(int i=0; i<vertice;++i)
    {
        for(int j=0; j<vertice;++j)
        {
            std::cout<<std::setw(7)<<std::fixed << std::setprecision(2)<< static_cast<double>(matrix[i][j]);
        }
        std::cout<<"\n";
    }
}
bool MatrixGraph::pathExists(int from, int to)
{
    if(from<0||from>=vertice||to<0||to>=vertice)
    {
        return false;
        //throw exception
    }
    std::vector<bool>visited(vertice);
    for (int i = 0; i < vertice; ++i) 
    {
        visited[i] = false;
    }
    Queue<int> q;
    visited[from]=true;
    q.enqueue(from);
    while (q.isEmpty()==false)
{
    int curr = q.front();
    q.dequeue();
    if (curr == to){
        return true;
    }
    for (int i=0; i<vertice; i++)
    {
        if(visited[i]==false && matrix[curr][i]>0.00)
        {
            visited[i]=true;
            q.enqueue(i);
        }      
    }
}    
return false;
}
std::vector<int> MatrixGraph::getBFSPath(int strt, int end)
{
    strt = strt - 1 ;
    end = end - 1 ;
    if(strt<0||strt>=vertice||end<0||end>=vertice)
    {
        //throw exception
        return {};
    }
    std::vector<bool>parent(vertice);
    for (int i = 0; i < vertice; ++i) 
    {
        parent[i] = -1;
    }
    std::vector<bool>visited(vertice);
    for (int i = 0; i < vertice; ++i) 
    {
        visited[i] = false;
    }
    Queue<int> q;
    visited[strt]=true;
    q.enqueue(strt);
    while (q.isEmpty()==false)
{
    int curr = q.front();
    q.dequeue();
    if (curr == end)
    {
        std::vector<int>path;
        int i=curr;
        while(i>-1&&i<vertice)
            {
               // path.insert(path.begin(), i);
               path.push_back(i);
                i=parent[i];
            }
             reverse(path.begin(), path.end());
        return path;    
    }
    for (int i=0; i<vertice; i++)
    {
        if(visited[i]==false && matrix[curr][i]>0.00)
        {
            visited[i]=true;
            parent[i]=curr;
            q.enqueue(i);
        }
    }
}
return{};
}
int MatrixGraph::getMinDist(std::vector<float>& minDist, std::vector<bool>& visited)
{
    int vert=-1;
        for(int j=0;j<vertice;j++)
        {
            if(visited[j]==false)
            if((vert==-1||minDist[j]<minDist[vert]))
            {
                vert=j;
            }
        }
    return vert;
}
std::vector<int> MatrixGraph::getDijkstraPath(int strt, int end)
{
    strt = strt - 1 ;
    end = end - 1;
    std::vector<float> minDist(vertice);
    for (int i = 0; i < vertice; ++i) 
    {
        minDist[i] = std::numeric_limits<float>::max();
    }
    std::vector<int> parent(vertice);
    for (int i = 0; i < vertice; ++i) 
    {
        parent[i] = -1;
    }
    std::vector<bool>visited(vertice);
    for (int i = 0; i < vertice; ++i) 
    {
        visited[i] = false;
    }
    minDist[strt]=0;
    for(int i=0;i<vertice;i++)
    {
        int vert=getMinDist(minDist,visited);
        if(vert == -1 || minDist[vert]==std::numeric_limits<float>::max())
        {
            //throw exception
            break;
        }
        visited[vert]=true;
        for (int a = 0; a < vertice; a++){
            if(!visited[a] && matrix[vert][a] && minDist[vert]+matrix[vert][a]<minDist[a])
                {minDist[a]=minDist[vert]+matrix[vert][a];
                parent[a]=vert;
                }
        }
    }
    std::vector<int>path;
        int i=end;
        while(i>-1&&i<vertice)
            {
                path.push_back(i);
                i=parent[i];
            }
            reverse(path.begin(), path.end());
            if (path.size() == 1 && path[0] != strt) 
        path.clear();
        return path;
}
 std::vector<std::vector<int>> MatrixGraph::getDijkstraAll(int strt) {
            strt = strt - 1 ;
        std::vector<std::vector<int>> allPaths;
        allPaths.resize(vertice);
        for (int end = 0; end < vertice; end++) {
            if (end != strt) { 
                allPaths[end] = getDijkstraPath(strt + 1, end+1);
            } 
        }
        return allPaths;

 }








