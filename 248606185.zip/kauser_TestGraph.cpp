/*
Author: Jameela Kauser
Date: 4/20/2024
Description: Main fucntion to connect all the files and print menu to prompt user for choice and do the necessary
*/
#include "MatrixGraph_kauser.h"
#include <iostream>
#include <iomanip> 
#include <fstream>
#include <sstream>
#include <limits>
using namespace std;

int main(int argc, char* argv[])
{
    string graphType = argv[1];  
    string filePath = argv[2];
    bool undirected= false;
     if (argc > 3 &&  string(argv[3]) == "-ud"){
        undirected = true;
     }
      bool weighted;
     if ( graphType == "-w"){
         weighted = 1;
     }

     ifstream file(filePath);
     int vertices, edges;
    file >> vertices >> edges;
    MatrixGraph graph(vertices, undirected);
     int v1, v2;
    float weight;
    if (weighted) {
    for (int i = 0; i < edges; i++) {
            file >> v1 >> v2 >> weight;
            graph.addEdge(v1 - 1, v2 - 1, weight);
            if (undirected)
                graph.addEdge(v2 - 1, v1 - 1, weight);
    }
    }
    else {
        for (int i = 0; i < edges; i++) {
            file >> v1 >> v2;
            graph.addEdge(v1 - 1, v2 - 1, 1);  
            if (undirected)
                graph.addEdge(v2 - 1, v1 - 1, 1);
        }
    }
    file.close();
    int choice;
    string filename;
    ofstream outFile;
    do
    {
      std::cout<<"Welcome to the Graph tester!\n";
      std::cout << "1) Print the graph\n";
      std::cout << "2) Find a BFS path\n";
        std::cout << "3) Find a Single Dijkstra Path\n";
        std::cout << "4) Find all Dijkstra Paths from a start\n";
        std::cout << "5) Start a file\n";
        std::cout << "6) Add a BFS path to the file\n";
        std::cout << "7) Add single Dijkstra Path to file\n";
        std::cout << "8) Add all Dijkstra Paths from a start\n";
        std::cout << "0) Quit\n";
        std::cin >> choice;
        switch(choice)
        {
            case 1:
            cout<< graph.toString();
            break;
            case 2:
            cin>>v1>>v2;
            try {
            vector<int> bfsPath = graph.getBFSPath(v1,v2);
            if(bfsPath.empty())
            {
                cout<<"No BFS path from "<<v1<<" to "<<v2<<".\n";
            }
            else
            {
                cout << "BFS path from " << v1 << " to " << v2 << " is:\n";
                cout<<"["<< setw(2)<<bfsPath[0]<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(graph.getEdgeWeight(bfsPath[0],bfsPath[0]))<<"]";
                for (int i = 1; i < bfsPath.size(); i++) {
                            cout<<"==>["<< setw(2)<<bfsPath[i]<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(graph.getEdgeWeight(bfsPath[i],bfsPath[i-1]))<<"]";
                        }
                        cout << endl;
            }
            }
            catch (exception& e) {
            }
            break;





            case 3:
            cin>>v1>>v2;
            try {
            vector<int> dijkstraPath = graph.getDijkstraPath(v1, v2);
            if(dijkstraPath.front()==v2-1)
            {
                cout<<"No DIJKSTRA path from "<<v1<<" to "<<v2<<".\n";
            }
            else
            {
                float weight = 0.00;
                cout << "DIJKSTRA path from " << v1 << " to " << v2 << " is:\n";
                cout<<"["<< setw(2)<<dijkstraPath[0]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(0.00)<<"]";
                //cout<<dijkstraPath.size();
                for (int i = 1; i < dijkstraPath.size(); i++) {
                  //  if (dijkstraPath[i]==0)
                    //break;
                    weight = weight + graph.getEdgeWeight(dijkstraPath[i-1],dijkstraPath[i]);
                            cout<<"==>["<< setw(2)<<dijkstraPath[i]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(weight)<<"]";
                }
                        cout << endl;
            }
            }
            catch (exception& e) {
            }
            break;




            case 4:
            cin >> v1;
            try{
            vector<vector<int>> allDijkstraPath = graph.getDijkstraAll(v1);
           
           for (size_t i = 0; i < allDijkstraPath.size(); ++i) {
           const vector<int>& path = allDijkstraPath[i];
        if ((undirected == true && path.empty()) || (undirected == false && path.empty() && i == v1 -1 ) ) {
               // cout << "No DIJKSTRA path from " << v1 << " to " << (i + 1) << "\n";
               cout << "DIJKSTRA Paths start at Vertex " << v1 << "\n";
                continue;
            } 
            
            
           cout<<"Path to " << path.back()+1 << ": ";
           if ((undirected == true &&path.front()==path.back() && path.size() == 2)  || (undirected == false && path.empty()))
            {
           cout<<"No DIJKSTRA path from "<<v1<<" to "<<path.back()<<"\n";
            }
            else {
            cout<<"["<< setw(2)<<path[0]+1 <<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(0.00)<<"]";
            float weight = 0.00;
            for (int j=1; j<path.size(); j++) {
            weight = weight + graph.getEdgeWeight(path[j-1],path[j]);
            cout<<"==>["<< setw(2)<<path[j]+1<<":"<<setw(6)<<std::fixed << std::setprecision(2) << static_cast<double>(weight)<<"]";
           }
            }
            cout << "\n";
            }
            }
            catch (exception& e) {
            }
            break;




            case 5:
            cout << "Enter filename to start a file: ";
            cin >> filename;
            outFile.open(filename);
            outFile << vertices << " " << edges << "\n";
            for (int i = 0; i < vertices; i++) {
                for (int j=0; j< vertices ; j++){
                    if(graph.adjacent(i,j)) {
        if (weighted){
        outFile << i+1 << " " << j+1 << " " << graph.getEdgeWeight(i,j) << "\n";                 
                    }
        else {
        outFile << i+1 << " " << j+1 << " " << "\n";
        }       
                }
            }
            }
            outFile.close();
            break;




            case 6:
            cin>>v1>>v2;
            outFile.open(filename,ios::app);
             if (!outFile) {
            cerr << "No file has been created yet." << endl;
            break;
            }
            try {
            vector<int> bfsPath = graph.getBFSPath(v1,v2);
            if(bfsPath.empty())
            {
                outFile<<"No BFS Path from "<<v1<<" to "<<v2<<".\n";
            }
            else
            {
                outFile << "BFS Path from " << v1 << " to " << v2 << " is:\n";
                outFile<<"["<< setw(2)<<":"<<setw(5)<<graph.getEdgeWeight(bfsPath[0],bfsPath[0])<<"]";
                for (int i = 1; i < bfsPath.size(); i++) {
                            outFile<<"==>["<< setw(2)<<":"<<setw(5)<<graph.getEdgeWeight(bfsPath[i],bfsPath[i-1])<<"]";
                        }
                        outFile << endl;
            }
            }
            catch (exception& e) {
            }
            outFile.close();
            break;



            case 7: 
            cin>>v1>>v2;
            outFile.open(filename,ios::app);
             if (!outFile) {
            cerr << "No file has been created yet." << endl;
            break;
            }
            try {
            vector<int> dijkstraPath = graph.getDijkstraPath(v1, v2);
            if(dijkstraPath.empty())
            {
                 outFile<<"No DIJKSTRA path from "<<v1<<" to "<<v2<<".\n";
            }
            else
            {
                float weight = 0.00;
                 outFile << "DIJKSTRA Path from " << v1 << " to " << v2 << " is:\n";
                 outFile<<"["<< setw(2)<<":"<<setw(5)<<graph.getEdgeWeight(dijkstraPath[0],dijkstraPath[0])<<"]";
                for (int i = 1; i < dijkstraPath.size(); i++) {
                    weight = weight + graph.getEdgeWeight(dijkstraPath[i],dijkstraPath[i-1]);
                 outFile<<"==>["<< setw(2)<<":"<<setw(5)<<weight<<"]";
                }
                         outFile << endl;
            }
            }
            catch (exception& e) {
            }
            outFile.close();
            break;





            case 8:
            cin >> v1;
            outFile.open(filename,ios::app);
             if (!outFile) {
            cerr << "No file has been created yet." << endl;
            break;
            }
            try{
            vector<vector<int>> allDijkstraPath = graph.getDijkstraAll(v1);
           outFile << "DIJKSTRA Paths start at Vertex " << v1 << "\n";
           for (size_t i = 0; i < allDijkstraPath.size(); ++i) {
           const vector<int>& path = allDijkstraPath[i];
           outFile<<"Path to " << path[path.back()]<<": ";
           if(path.empty())
            {
             outFile<<"No DIJKSTRA path from "<<v1<<" to "<<path[path.back()]<<"\n";
            }
            else {
            outFile<<"["<< setw(2)<<path[0]<<":"<<setw(5)<<graph.getEdgeWeight(path[0],path[0])<<"]";
            float weight = 0.00;
            for (int i=1; i<path.size(); i++) {
            weight = weight + graph.getEdgeWeight(path[i],path[i-1]);
            outFile<<"==>["<< setw(2)<<":"<<setw(5)<<weight<<"]";
           }
            }
            }
            }
            catch (exception& e) {
            }
            outFile.close();
            break;




            case 0:
            exit(0);
            break;




            case 999:
            graph.printRaw();



            break;
            default:
                cout << "Invalid choice. Please try again.\n";
        }
     }
     while(choice != 0);
    }