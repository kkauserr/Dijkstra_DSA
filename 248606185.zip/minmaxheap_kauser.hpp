/*
Author: Jameela Kauser
Date: 4/20/2024
Description: This assignment contains a type of DSA called Mina nd Max Heap that used to solve problems.
*/
#include <iostream>
#include <stdexcept>
#include <limits.h>
#include <concepts>
using namespace std;

//MinHeap ADT
template<typename T> class MinHeap
{
    private:
    T* arrayHeap;
    int cap;
    int currentSize;
    void MinHeapify(int ind) //Heapify method that supports MinHeap
    {
        int small=ind;
        int leftChild=2*ind+1;
        int rightChild= 2*ind+2;
        if(leftChild<currentSize)
        {
            if(arrayHeap[leftChild]<arrayHeap[ind])
            {
                small=leftChild;
            }
        }
        if(rightChild<currentSize)
        {
            if(arrayHeap[rightChild]<arrayHeap[small])
            {
                small=rightChild;
            }
        }
        if (small!=ind)
        {
            T temp=arrayHeap[ind];
            arrayHeap[ind]=arrayHeap[small];
            arrayHeap[small]=temp;
            MinHeapify(small);
        }
    }
    public:
    MinHeap()//Constructor
    {
        currentSize=0;
    }
    MinHeap(int size)//constructor
    {
        this->cap=size;
        this->currentSize=0;
        this->arrayHeap=new T [cap];
    }
    ~MinHeap()//destructor
    {
        empty();
    }
    void enqueue(T newElement)//adding elements to Heap
    {
        if(currentSize==cap)
        {
            throw range_error("Heap full");
        }
        arrayHeap[currentSize]= newElement;
        int curr = currentSize;
        while(curr>0 && arrayHeap[((curr-1)/2)]>arrayHeap[curr])
        {
                T temp = arrayHeap[((curr-1)/2)];
                arrayHeap[((curr-1)/2)]=arrayHeap[curr];
                arrayHeap[curr]=temp;
                curr=((curr-1)/2);
            
        }
        currentSize++;
    }
    void dequeue ()//removing elements
    {
        if (isEmpty())//checks if the Heap is empty
        {
            throw out_of_range("Attempted to delete but MinHeap is empty");
        }
        T rootVal=arrayHeap[0];
        arrayHeap[0]=arrayHeap[currentSize-1];
        currentSize--;
        MinHeapify(0);
    }
    T peek()//returns min value
    {
        return arrayHeap[0];
    }
    int getSize()//returns size
    {
        return currentSize;
    }
    int getCapacity()//returns capacity
    {
        return cap;
    }
    bool isEmpty()//returns true or false is the Heap is empty
    {
        return (currentSize==0);
    }
      void empty()//empties Heap
    {
        while(!isEmpty())
        {
            dequeue();//empty elements
        }
        delete[] arrayHeap;//destroys Heap
    } 

};

// MaxHeap ADT

template <typename T> class MaxHeap
{
    private:
    T* arrayHeap;
    int cap;
    int currentSize;
    void MaxHeapify(int ind)//supports MaxHeap
    {
        int leftChild=2*ind+1;
        int rightChild= 2*ind+2;
        int largest= ind;
        if(leftChild<currentSize && arrayHeap[leftChild]>arrayHeap[ind])
            largest = leftChild;
        if(rightChild<currentSize && arrayHeap[rightChild]>arrayHeap[largest])
            largest = rightChild;
        if(largest != ind)
        {
            T temp=arrayHeap[ind];
            arrayHeap[ind]=arrayHeap[largest];
            arrayHeap[largest]=temp;
            MaxHeapify(largest);
        }
    }
    public:
    MaxHeap()//constructor
    {
        currentSize=0;
    }
    MaxHeap(int size)//constructor
    {
        this->cap=size;
        this->currentSize=0;
        this->arrayHeap=new T [cap];

    }
    ~MaxHeap()//destructor
    {
        empty();
    }
    void enqueue(T newElement)//adding elements
    {
        if(currentSize==cap)
        {
            throw range_error("Heap full");
        }
        arrayHeap[currentSize]= newElement;
        int curr = currentSize;
        while(curr>0 && arrayHeap[curr]>arrayHeap[((curr-1)/2)])
        {
            T temp=arrayHeap[curr];
            arrayHeap[curr]= arrayHeap[((curr-1)/2)];
            arrayHeap[((curr-1)/2)]=temp;
            curr=((curr-1)/2);
        }
        currentSize++;
    }
    void dequeue ()//removes elements
    {
        if (isEmpty())//checks if Heap array is empty
        {
            throw out_of_range("Attempted to delete but MaxHeap is empty");
        }
        T rootVal=arrayHeap[0];
        arrayHeap[0]=arrayHeap[currentSize-1];
        currentSize--;
        MaxHeapify(0);
    }
    T peek()//returns max value
    {
        return arrayHeap[0];
    }
    int getSize()//returns size
    {
        return currentSize;
    }
    int getCapacity()//returns capacity
    {
        return cap;
    }
    bool isEmpty()//returns true of false if the Heap array is empty
    {
        return (currentSize==0);
    }
      void empty()//empties Heap
    {
        while(!isEmpty())
        {
            dequeue();//removes elements
        }
        delete[] arrayHeap;//destroys Heap
    }
};